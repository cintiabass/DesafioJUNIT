
public class Resposta {

	public static final Resposta DELACAO = null;

}
